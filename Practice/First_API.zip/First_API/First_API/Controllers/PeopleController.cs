﻿using First_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace First_API.Controllers
{
    /// <summary>
    /// This Gives all information about Persons
    /// </summary>
    public class PeopleController : ApiController
    {
        List<Person> people = new List<Person>();
        public PeopleController()
        {
            people.Add(new Person { FirstName = "Satyam", LastName = "Mandal", id = 2 });
            people.Add(new Person { FirstName = "Satyam", LastName = "Mandal", id = 1 });
            people.Add(new Person { FirstName = "Satyam", LastName = "Mandal", id = 3 });
        }
        /// <summary>
        /// Get a List of first name of users
        /// </summary>
        /// <param name="Id">Unique Identifier for this persion</param>
        /// <returns>First Name</returns>
        [Route("api/People/GetFirstName/{id:int}")]
        [HttpGet,HttpPost]
        public List<string> GetFirstName(int Id)
        {
            List<string> output = new List<string>();
            foreach (var p in people){
                if(p.id==Id)
                        output.Add(p.FirstName);
            }
            return output;
        }
        // GET: api/People
        public List<Person> Get()
        {
            return people;
        }

        // GET: api/People/5
        public Person Get(int id)
        {
            return people.Where(x => x.id == id).FirstOrDefault();
        }

        // POST: api/People
        public void Post(Person val)
        {
            people.Add(val);
        }

        // PUT: api/People/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/People/5
        public void Delete(int id)
        {
        } 
    }
}
