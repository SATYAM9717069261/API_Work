﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace First_API.Models
{
    /// <summary>
    /// Represent Specific User
    /// </summary>
    public class Person
    {/// <summary>
    /// id from SQL
    /// </summary>
        public int id { get; set; } = 0;
        /// <summary>
        /// User First name
        /// </summary>
        public string FirstName { get; set; } = "";
  /// <summary>
  /// User Secand Name
  /// </summary>
        public string LastName { get; set; } = "";
        
    }
}